package com.example.BorrowerService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BorrowerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
